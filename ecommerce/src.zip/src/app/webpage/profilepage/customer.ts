export class Customer {
    
    custid:number;
    custname:string;
    custusername:string;
    custpassword:string;
    Custphone:string;
    custemail:string;
    custaddress:string;
}
