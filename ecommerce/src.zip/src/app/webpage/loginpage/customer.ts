export class Customer {
    
}
