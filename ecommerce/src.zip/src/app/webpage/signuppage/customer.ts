export class Customer {
    
    CustId:number;
    CustName:string;
    CustUserName:string;
    CustPassword:string;
    CustPhone:string;
    CustEmail:string;
    CustAddress:string;
}
