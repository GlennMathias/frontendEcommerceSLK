import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/product.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Product } from '../product';
import { CustomerService } from 'src/app/customer.service';
import { OrderdetailsService } from 'src/app/orderdetails.service';

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {

  products : Observable<Product[]>;
  cart: any = {};
  qty = {};

  constructor(private productService : ProductService,private orderDetails : OrderdetailsService,private route : Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData()
  {
    this.products=this.productService.getProducts();
  }

  printActUser()
  {
    console.log(CustomerService.getActiveId());
  }

  addToCart(prodId,qty)
  {
    console.log(prodId,qty);
   this.orderDetails.addToCartService(prodId,qty);
  }

}



