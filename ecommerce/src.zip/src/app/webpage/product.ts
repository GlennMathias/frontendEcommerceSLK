export class Product {
    proCatId:number;
    proDes:string;
    proPrice:number;
    proId:number;
    proName:string;
    prodImg:string;

}
