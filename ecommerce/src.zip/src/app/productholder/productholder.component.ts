import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productholder',
  templateUrl: './productholder.component.html',
  styleUrls: ['./productholder.component.css']
})
export class ProductholderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
