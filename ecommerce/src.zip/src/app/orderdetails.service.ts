import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CustomerService } from './customer.service';

@Injectable({
  providedIn: 'root'
})
export class OrderdetailsService {

  private baseUrl="http://localhost:8080/";
  constructor(private http: HttpClient) { }
  static currentOrderId :number=0;
  total :number;

  getCart():Observable<any>
  {
    return this.http.get(`${this.baseUrl+"viewCart/"+OrderdetailsService.currentOrderId}`);
  }

  addToCartService(prodId,qty)
  {
    console.log(`${this.baseUrl+"addCart/"+OrderdetailsService.currentOrderId+"/"+prodId+"/"+qty}`);
    
    this.http.get(`${this.baseUrl+"addCart/"+OrderdetailsService.currentOrderId+"/"+prodId+"/"+qty}`).subscribe((data)=>{console.log(data)},(error)=>{console.log(error)});
  }

  createOrder()
  {
    
    this.http.get(`${this.baseUrl}/userLogin/${CustomerService.getActiveId()}`).subscribe((data)=>{OrderdetailsService.currentOrderId=Number(data);},
    (error)=>{console.log(error)});
    
  }

  getTotalService():Observable<any>
  {
    console.log(`${this.baseUrl}getTotal/${OrderdetailsService.currentOrderId}`);
    return  this.http.get(`${this.baseUrl}getTotal/${OrderdetailsService.currentOrderId}`);
      
  }

}
